# PDF MIX — base real de aplicação

Este projeto é a base de uma aplicação Next.js com Supabase: catálogo público, autenticação preparada, papéis de usuário, solicitações de vendedores, produtos aguardando aprovação e pedidos.

## Rodar localmente
1. Instale Node.js LTS em um computador.
2. Na pasta do projeto, rode `npm install`.
3. Copie `.env.example` para `.env.local`.
4. Crie um projeto Supabase e preencha URL e chave pública no `.env.local`.
5. No Supabase, execute `supabase/schema.sql` no SQL Editor.
6. Rode `npm run dev`.

## O que ainda precisa ser configurado antes de vender
- Cadastro/recuperação de contas e criação segura do perfil inicial.
- Fluxo administrativo seguro para aprovar vendedores e produtos.
- Bucket privado de PDFs e links temporários autorizados após pagamento.
- Integração real com provedor de pagamento, confirmação por webhook assinado, estornos e conciliação.
- Para marketplace, contrato e capacidade de divisão de pagamentos/payouts do provedor.
- Termos, privacidade, suporte, regras de reembolso e revisão jurídica/contábil.

**Não está habilitado para receber dinheiro ainda.** Não coloque chaves secretas no navegador, no GitHub ou nesta conversa. Um responsável adulto deve cuidar das contas financeiras e confirmar que o provedor permite a operação e o modelo de marketplace. O SQL é uma base inicial e precisa de revisão de segurança antes de produção.
