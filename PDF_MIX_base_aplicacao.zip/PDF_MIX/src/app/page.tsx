import { createClient } from "@/lib/supabase/server";
export default async function Home() {
 let products:any[] = [];
 try {
   const supabase = await createClient();
   const {data} = await supabase.from("products").select("id,title,description,price_cents,cover_url").eq("status","approved").order("created_at",{ascending:false});
   products = data ?? [];
 } catch {}
 return <main className="wrap">
  <section className="hero"><span className="tag">LOJA DIGITAL</span><h1>Seu próximo PDF favorito está aqui.</h1><p>Descubra materiais digitais de vendedores aprovados pela PDF MIX.</p><a className="button" href="#catalogo">Explorar catálogo</a></section>
  <h2 id="catalogo">Catálogo</h2>
  {!products.length ? <div className="card"><h3>Estamos preparando a vitrine!</h3><p className="muted">Os produtos aparecerão aqui depois que o banco de dados estiver conectado e os primeiros PDFs forem aprovados.</p></div> :
   <div className="grid">{products.map(p=><article className="card" key={p.id}>{p.cover_url&&<img src={p.cover_url} alt="" style={{width:"100%",borderRadius:10}}/>}<h3>{p.title}</h3><p className="muted">{p.description}</p><strong>R$ {(p.price_cents/100).toFixed(2).replace(".",",")}</strong></article>)}</div>}
 </main>;
}