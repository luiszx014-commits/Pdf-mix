 "use client";
import {useState} from "react";
import {createBrowserClient} from "@supabase/ssr";
export default function Login(){const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [msg,setMsg]=useState("");
 async function submit(e:React.FormEvent){e.preventDefault();const s=createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);const {error}=await s.auth.signInWithPassword({email,password});setMsg(error?.message??"Login realizado. Atualize a página.");}
 return <main className="wrap"><div className="card"><h1>Entrar</h1><form onSubmit={submit}><label>E-mail</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/><label>Senha</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/><button>Entrar</button></form><p className="muted">{msg}</p></div></main>}
