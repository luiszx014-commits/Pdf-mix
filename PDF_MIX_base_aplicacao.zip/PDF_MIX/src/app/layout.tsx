import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "PDF MIX", description: "Marketplace de produtos digitais em PDF" };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="pt-BR"><body><header className="top"><a className="brand" href="/">PDF MIX</a><nav><a href="/vender">Quero vender</a></nav></header>{children}<footer>PDF MIX • Produtos digitais em PDF</footer></body></html>;
}