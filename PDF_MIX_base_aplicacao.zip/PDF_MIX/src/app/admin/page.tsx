import { createClient } from "@/lib/supabase/server";
export default async function AdminPage(){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user) return <main className="wrap"><div className="card"><h1>Painel administrativo</h1><p>Entre com uma conta autorizada para continuar.</p><a href="/login">Entrar</a></div></main>;
 const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin") return <main className="wrap"><div className="card"><h1>Acesso restrito</h1><p>Sua conta não tem permissão de administrador.</p></div></main>;
 const {data:pending}=await supabase.from("vendor_applications").select("*").eq("status","pending");
 return <main className="wrap"><h1>Administração</h1><div className="card"><h2>Solicitações pendentes</h2>{pending?.length?pending.map(v=><p key={v.id}>{v.store_name} — {v.description}</p>):<p>Nenhuma solicitação pendente.</p>}</div></main>;
}