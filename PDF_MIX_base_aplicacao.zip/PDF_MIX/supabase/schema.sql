-- Execute no SQL Editor do projeto Supabase.
create type public.account_role as enum ('customer','vendor','admin');
create type public.review_status as enum ('pending','approved','rejected');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null default '',
 role public.account_role not null default 'customer',
 created_at timestamptz not null default now()
);
create table public.vendor_applications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 store_name text not null,
 description text not null,
 status public.review_status not null default 'pending',
 created_at timestamptz not null default now()
);
create table public.products (
 id uuid primary key default gen_random_uuid(),
 vendor_id uuid not null references public.profiles(id),
 title text not null,
 description text not null,
 price_cents integer not null check(price_cents > 0),
 file_path text not null,
 cover_url text,
 status public.review_status not null default 'pending',
 created_at timestamptz not null default now()
);
create table public.orders (
 id uuid primary key default gen_random_uuid(),
 buyer_id uuid not null references public.profiles(id),
 product_id uuid not null references public.products(id),
 amount_cents integer not null check(amount_cents > 0),
 payment_status text not null default 'pending' check(payment_status in ('pending','paid','refunded','failed')),
 provider_reference text,
 created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.vendor_applications enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
create policy "profiles view own" on public.profiles for select to authenticated using(id=auth.uid());
create policy "approved products public" on public.products for select using(status='approved');
create policy "vendors view own applications" on public.vendor_applications for select to authenticated using(user_id=auth.uid());
create policy "users submit vendor application" on public.vendor_applications for insert to authenticated with check(user_id=auth.uid());
create policy "vendors view own products" on public.products for select to authenticated using(vendor_id=auth.uid());
create policy "vendors create pending products" on public.products for insert to authenticated with check(vendor_id=auth.uid() and status='pending');
create policy "buyers view own orders" on public.orders for select to authenticated using(buyer_id=auth.uid());
-- Admin actions and payment confirmation must run in trusted server-side code,
-- never by trusting a browser request. Do not expose the service-role key.
